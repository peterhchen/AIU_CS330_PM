# compile 
# 1-thread/1-block
# n-thread/1-block
# n-thread/m-block
./nvcc_01_vec_add.scr
./nvcc_02_vec_add.scr
./nvcc_03_vec_add.scr
