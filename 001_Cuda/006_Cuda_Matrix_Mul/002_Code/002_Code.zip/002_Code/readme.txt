# compile 
# 1-thread/1-block
# n-thread/1-block
# n-thread/m-block
./nvcc_01_mat_add.scr
./nvcc_02_mat_add.scr
